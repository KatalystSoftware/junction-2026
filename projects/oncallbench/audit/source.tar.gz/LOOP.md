# Improvement loop: on-call incident response on a generated estate

Process: `docs/overnight-loop.md`. Owner: Claude (this file and `metrics.json`). Builder: a fresh
sub-agent per round. Verifier: a fresh GPT 6.1 Sol reviewer per round. Agents under test: OpenCode
in Harbor 0.25.0.

## Report (16:02 EET, Sat 14 Nov; closed after round 10)

**Verdict: there is a gap for the judged agent, and it comes from judgment, not speed.** Claude
Opus 5.5 scored 0.91 of the scripted reference on level 3. On level 4, built from public
postmortems and as it now ships, it averages **0.31** over nine runs on the held-out seeds
(median 0.18, range 0.03-0.80). **Level 4 is the submit candidate.** Level 5 adds variety but no
further gap.

### Gap per level

Gap = 1 - mean frontier score (Opus and Gemini) on held-out seeds 101-103, as fixed in round 0.

| Level | What it adds | Opus 5.5 | Gemini 3.1 Pro | Sonnet 5.5 | Gap | Opus-only gap |
| --- | --- | --- | --- | --- | --- | --- |
| 3 | first budget's hardest level (report below) | 0.91 (5 runs) | 0.27 (3) | 0.64 (1) | 0.41 | 0.09 |
| **4, as shipped** (round 10) | callers retry; a hot service stays overloaded after its fix; `throttle`; a rollback can tip a service; the instruction says a healthy edge fails under 1% | **0.31** (9 runs, 3 per seed) | 0.00 (1) | 0.02 (1) | **0.84** | **0.69** |
| 4, before the healthy-baseline sentence (rounds 4, 6) | same level, older instruction | 0.57 (4 runs); 0.44 over 7 runs on 6 seeds | 0.00 (3) | 0.26 (1) | 0.71 | 0.43 |
| 5 (rounds 7-9, older instruction) | level 4 + a fault that fails and recovers every 5 minutes; a status page down by coincidence; the quiet fault a deploy or a config | 0.53 (6 runs); 0.55 over 9 runs on 6 seeds | 0.15 (3) | 0.00 (1) | 0.66 | 0.47 |

The shipped level separates cleanly on one decision: the two Opus runs that added capacity
before rolling back the quiet fault's service, and wasted nothing, scored 0.73 and 0.80; the six
that rolled back unprotected scored 0.03-0.59.

### Rounds of the second budget

| Round | Batch | Decision | Why |
| --- | --- | --- | --- |
| 4 | Research (`postmortems.md`), then level 4: retry storms, `throttle`, mitigations that backfire | **kept** | gates and review passed; Opus 0.91 -> 0.57, gap 0.41 -> 0.71 |
| 5 | Level 5, first build: cycle fault, traffic campaign, status page | **reverted** before any agent run | the reference reached only 0.54-0.82 of the oracle; the campaign broke its sizing; a fairness question was open |
| 6 | No lever: level 4 on three more held-out seeds | - | Opus 0.79, 0.00, 0.00: the gap holds off the fixed seeds |
| 7 | Level 5 rebuilt without the campaign | **kept, not the candidate** | gates and review passed; with the full basis the gap is 0.66 against level 4's 0.71 |
| 8 | Level 6: failover onto a small standby | **reverted** before any agent run | gate missed on two held-out seeds; free pre-sizing of standbys was a loophole; third level in a row to need a richer rich edge |
| 9 | No lever: second Opus run per fixed seed at level 5 | - | 0.65, 0.89, 0.21 |
| 10 | No lever: default level pinned to 4; the instruction states the healthy baseline; level 4 re-measured three times per seed | **kept** | fairer, and Opus 0.57 -> 0.31: the sentence removed the "4% is normal" excuse and exposed the unprotected rollback |

### Failure taxonomy (Opus 5.5, 16 runs on levels 4-5 before round 10; every run classified from its transcript)

Round 10's nine runs are classified in its notes: 6 unprotected rollbacks, 2 clean protected
ones, 1 innocent caller rolled back. The table below is the earlier sixteen.

All meaningful: each was avoidable with what the tools showed, and nothing was charged unfairly.
Trials are folders under `jobs/` (not committed; one level-4 run is committed under `runs/`).

| Failure | Runs | Example, in Opus's words |
| --- | --- | --- |
| Rolls back a hot service without adding capacity first; the retries collapse the richest edge | 6 of 16 (it protects the same rollback in 5 others) | `r7-l5-s101-opus-143149`: "Rollback without headroom: I started the quotes-svc rollback without checking whether it had room to absorb the extra retries. Scaling it first would have avoided the overload, which cost about 20 minutes of partner-api losing around 40% of its revenue." |
| Reads a real traffic overload as a retry storm, or simply leaves a throttle on: 12 to 76 minutes of rejected traffic | 8 of 16 | `r4-l4-s101-opus-130256`: "When I lifted the throttle, pricing-svc fell straight back into overload. Its real traffic is now larger than 6 replicas can handle" |
| Undoes the wrong one of two same-minute changes, or the innocent caller ($10,000 each) | 4 of 16 | `r4-l4-s102-opus-131058`: "I reverted the config change first without reading what it did, and that didn't help" |
| Takes the quiet fault for the baseline and never fixes it | 2 of 16 (both seed 103) | `r4-l4-s103-opus-131117`: "all four customer-facing services ended back at their normal 4% error rate. Admin-portal ($21.6k/min) and partner-api were never affected." |
| The shift costs more than doing nothing | 3 of 16 | `r6-l4-s106-opus-140329`: "I rolled back payouts-svc when it didn't need it. That cost a $10k wasted-mitigation charge, plus about 6 minutes of roughly 30% errors on partner-api, our biggest earner" |
| Leaves a retry storm burning for 25-35 minutes after a correct fix | 2 of 16 | `r6-l4-s104-opus-140247`: "Caller retries kept loyalty-svc overloaded afterwards, so web and mobile only dropped to about 40% errors. Scaling loyalty-svc from 3 to 8 replicas at minute 38 cleared that" (the rollback was at minute 13) |
| Delay only | 3 of 16 | fixes 16-33 minutes behind the reference |

What did not fool Opus: the fault on a cycle (it found the publisher every time, late), the
status page, the batch-job decoy. Gemini and Sonnet fail the same ways, sooner and more often.

### Reward integrity

A fresh GPT 6.1 Sol review per kept level. Level 4: 3,343 random actions replay exactly, 256,118
comparisons show the past never changes, blanket scale or throttle scores zero, the reference is
never fined. Level 5: 7,200 random calls replay exactly, mitigations on the status page change
nothing, a correct publisher revert is never fined. Findings across both: five tells or
shortcuts, four fixed (a retry-share tell, two publisher tells, and at level 5 the quiet fault's
predictable type); kept as known limits:

- Level 4's quiet fault is always a deploy, so skipping its diffs saves about 1%. It needs
  knowledge from earlier episodes; level 5 varies the type.
- Retries are modelled as a share, not a volume (a throttle is slightly weaker than in reality,
  the same for agent and reference).
- The reference reaches 0.76-0.85 of an oracle that knows the faults, so an agent can beat it;
  the clip at 1 means that can only hide a gap.
- The one classification that was a judgment call (Opus reading the quiet fault's ~4% as
  normal) is settled: since round 10 the instruction says a healthy edge fails under 1%.

### Cost

Since 12:11: $18.70 of the $25 granted, 35 counted agent runs (25 Opus, 7 Gemini, 3 Sonnet), seven
rounds (4-10), closed at 16:02 against the 18:00 stop. Six further Opus runs were not counted
(three hit the Anthropic spend limit, three never started; round 10 notes). All budgets: $24.30,
11 Gemini runs in all.

### For whoever ships it

- `run.sh` and `eval.py` now default to level 4 (`incident.SUBMITTED`); levels 5 and below are
  opt-in with `LEVEL=`.
- The README's numbers and two of its statements were corrected in round 10 to match the shipped
  instruction. The committed run under `runs/` (0.57, seed 101) was recorded before the
  healthy-baseline sentence; the README says so.
- Run at most six agent containers at once on this machine: ten made Harbor's agent setup time
  out.
- Two levers were built and reverted, and are kept outside git as patches under `jobs/patches/`:
  the traffic campaign (round 5) and the failover onto a small standby (round 8). The second
  needs standby replicas to cost money before it tests anything.

## Report of the first budget (written 11:55 EET, Sat 14 Nov)

**Verdict: no gap for the judged agent. Stopped after two lever rounds, as the gate rule says.**
Claude Opus 5.5 scores 0.91 of the scripted reference on the hardest level (five runs on three
held-out seeds, range 0.88-0.93). It finds every cause, wastes nothing, and trails the reference by
a few simulated minutes per fix (20-35 minutes on the quiet fault in its two slowest runs). The levers do break the other models: Gemini 3.1 Pro averages
0.27 and Sonnet 5.5 scored 0.64. This is the fourth spike where Opus solves the task, and the first
where the same task clearly separates it from Gemini and Sonnet.

### Gap per round

Gap = 1 - mean frontier normalised score (Opus and Gemini), held-out seeds.

| Round | Level | What changed | Opus 5.5 | Gemini 3.1 Pro | Sonnet 5.5 | Gap | Opus-only gap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 0 | one fault, free queries | 1.00 (3 runs) | not run | - | 0.00 | 0.00 |
| 1 | 1 | three faults, two decoys | 0.97 (1) | not run | - | 0.03 | 0.03 |
| 1 | 2 | + queries and mitigations cost clock time | 0.94 (1) | 0.80 (1) | 0.95 | 0.13 | 0.06 |
| 2 | 3 | + 60 services, partial views, quiet gray failure, causes in diffs | 0.88 (1) | 0.41 (1) | 0.64 | 0.36 | 0.12 |
| 3 | 3 | confirm (no new lever) | 0.91 (5) | 0.27 (3) | - | **0.41** | **0.09** |

Round 2's single Opus run (0.88) was its slowest of five; the confirmation put it back above 0.9.
One Gemini score is re-scored after a fairness fix (0.31 as run, 0.40 fixed); with the scores as
run the Gemini mean is 0.24 and the gap 0.42.

### Batches

| Round | Batch | Decision | Why |
| --- | --- | --- | --- |
| 1 | Level 1: concurrent faults (primary, masked, late) and two loud decoys | kept | gates passed; Opus 1.00 -> 0.97 |
| 1 | Level 2: queries 2 min, mitigations 1 min to start, harsher disruption | kept | gap 0.00 -> 0.13; Gemini falls for the decoy |
| 2 | Level 3: scale, top-10 alerts, short windows, quiet gray failure, diffs, $10,000 per wasted mitigation | kept | gap 0.13 -> 0.36; more realistic, not less |
| 3 | Review fixes: diff shape and twin timing no longer give the answer away; scaling back to normal is not charged | kept | integrity and fairness; saved runs replay to the same cost |

Nothing was reverted. Ablation is by level (each level adds one batch): lever 1 costs Opus 0.03,
lever 2 another 0.03, lever 3 another 0.03. No single lever moves Opus much; lever 3 is what
breaks Gemini and Sonnet.

### Failure taxonomy (level 3 unless noted; trials are folders under `jobs/`, not committed)

| Failure | Who | Meaningful? | Example |
| --- | --- | --- | --- |
| Slow search for the quiet fault: breadth-first `get_metrics` at 2 minutes each instead of following the callers' logs | Opus (2 of 5 runs, costs 0.10-0.12), Gemini | yes | `r2-l3-s101-opus-112132`: fixed at minute 54; its own summary: "Partner-api was slow to fix. It ran at about 4.5% errors until minute 54, which is roughly $20k of lost revenue." |
| Late detection of the mid-shift fault: polls every 5 minutes and reads 2-3 things first | Opus (all runs, costs 0.03-0.07) | yes | `r3-l3-s102-opus-113119`: fault lands at minute 69, fixed at 80 (reference 77) |
| Blames the innocent caller of the quiet fault because its deploy came first | Sonnet, Gemini | yes | `r2-l3-s101-sonnet-112130`: "I rolled back returns-svc v121 first, because the errors started after that deploy. This was wrong." |
| Mitigates the loud decoy (the service running a batch job): restart, then scale up twice | Gemini (level 2 and 3) | yes | `r3-l3-s102-gemini-113121`: restart and three scales on catalog-svc, a rollback on an edge; cost above doing nothing, score 0.00 |
| Never finds the quiet fault | Gemini (1 of 3) | yes | `r3-l3-s103-gemini-113141`: inventory-svc never touched |
| Charged $10,000 for scaling a service back to its normal size | Gemini (2 runs) | **unfair, fixed** | same two runs; one score moves 0.31 -> 0.40, the other stays 0.00 |

No Opus failure was unfair, and none was a miss: all of its loss is delay.

### Reward integrity

Three independent reviews (GPT 6.1 Sol, a fresh reviewer each round): no receipt forgery, no leak
of the future, the seed or the level, no replay mismatch. Seven findings: five fixed, one accepted
as a limit, one rejected:

- A blind cycle of mitigations scored 0.95 at level 2. Fixed at level 3 ($10,000 per wasted
  mitigation; the `shotgun` policy scores at most 0.61). Level 2 keeps the weakness.
- Diff length and old logs each picked the harmful change without reading it (1.0 on all build
  seeds). Fixed; both shortcuts now score 0.30-0.82.
- Call budget not in the instruction; log window mislabelled. Fixed.
- With the simulator's source in hand, the harmful hunk can still be picked by subtracting the
  known length of each ordinary hunk (14 of 14 on the build seeds). Rejected as an exploit: the
  agent never sees the source, and spotting the hunk that is not routine is reading the diff.
  It is a real limit of a fixed table of 8 harmful and 15 ordinary hunks: a submitted version
  should generate them.
- A faster legal policy can beat the reference (it avoids 0.79-0.89 of what an all-knowing oracle
  avoids at level 3). Accepted: the score is clipped at 1, so this can only hide a gap.

Anchors in Harbor at level 3 (seed 101): reference 1.00, do-nothing 0.00, stop-early 0.00,
shotgun 0.55.

### Cost

$5.60 of the $25 budget: 16 agent runs (10 Opus, 4 Gemini, 2 Sonnet), scripted anchors at $0.
Three rounds of six used. Stopped at 11:55, deadline 13:30.

### If the team wants to continue

The only lever left that I expect to move Opus is the reference itself: at level 3 it is 11-21%
short of the oracle, and Opus sits about 9% behind it. A reference that follows the callers' logs
before reading any metric would lower `cost_ref` and turn Opus's delay into a larger share. That
is honest only if the reference still uses nothing but the tools. More quiet faults would add
more of the same delay, not a new kind of failure.


## Fixed before round 1 (never changed)

- **Normalised score** = (cost_null - cost) / (cost_null - cost_ref), clipped to 0..1. `cost_null`
  is the do-nothing run, `cost_ref` the scripted reference (`sim/policies.py: reference`), both on
  the same seed and level. The verifier computes it by replaying the signed action log.
- **Gap** = 1 - mean frontier normalised score, over the round's frontier runs.
- **Seeds.** Build seeds 1-5 (builders and tests may look at them). Held-out seeds 101, 102, 103
  (only measured, never inspected while building). The per-round frontier run uses held-out 101;
  a confirm uses all three.
- **Models.** Screen: `claude-sonnet-5-5`. Frontier: `claude-opus-5-5` and
  `gemini-3.1-pro-preview`, one run each per round; 3 + 3 only for a submit candidate. Gemini is
  never batched widely.
- **Budget.** At most 6 rounds, $25 of agent runs (sum of Harbor `cost_usd`), hard stop 13:30 EET
  Sat 14 Nov. Also stop after two rounds in a row without improvement, or after two lever rounds
  that leave Opus above 0.9.
- **Measurement.** `./eval.sh <round> <level> <seed> <run>...` runs baselines or agents in Harbor
  and appends one record per run to `metrics.json`.
- **Gates every round.** `eval.py` on build and held-out seeds: reference beats do-nothing,
  stop-early <= 0.05, exploiter < 0.9, 200 random episodes per seed replay byte-identically and
  never beat the reference by more than 2%.

## Decisions and reasons

- Round 0 was built by the owner, not a builder sub-agent: the gate had a 60-minute limit and the
  design had to be settled first. Builders start in round 1.
- The reward is outcome-only: cost of the shift from a replay of the action log. The mitigations
  applied are the agent's statement of the cause, so there is nothing to judge with a language
  model and nothing to self-report.
- A wasted mitigation costs $2,000 from level 0, so trying every mitigation on every alerting
  service (the exploiter policy) scores below the reference.
- Fuzz tolerance is 1.02, not 1.00: replica counts are integers, so a random policy can land on a
  slightly cheaper replica count than the reference's rule.
- Each episode is a copy of the task in a folder named by an opaque hash, so the seed and level
  are in nothing the agent can read.
- Levels are data (`incident.LEVELS`): every lever is a new level, old levels stay replayable, so
  a revert or an ablation is a level number, not a code archaeology exercise.
- When the clock is short, screen and frontier runs start together. This deviates from the funnel
  (screen first) and spends at most one Opus and one Gemini run on a round the screen solves.

## Round log

### Round 0: gate (10:14-10:20 EET, commit 4a124a9)

Level 0: 12 services, one fault, free queries. Opus 5.5 on the three held-out seeds:

| seed | fault | Opus score | actions | cost_usd |
| --- | --- | --- | --- | --- |
| 101 | overload on a data service | 0.99 | 22 | 0.13 |
| 102 | bad deploy | 1.00 | 23 | 0.14 |
| 103 | bad deploy | 1.00 | 24 | 0.19 |

Mean 1.00, gap 0.00. **The base task has no gap; the loop goes straight to the levers.** Scripted
anchors in Harbor on seed 1: reference 1.0, do-nothing 0.0.

What the transcripts show, and what the levers aim at: Opus made 5 to 11 telemetry queries before
its first mitigation, and on seed 101 it called `finish` at minute 25 after one fix. Neither costs
anything at level 0.

No verifier in round 0: the gate measures the base task, and the round-1 verifier reviews the
whole spike.

### Round 1: levers 1 and 2 (plan 10:27, build commit e7a11c0)

Hypotheses:

1. **Concurrent faults with loud decoys (level 1).** Three faults per shift: a primary, one masked
   under it, one landing at minute 20-50; plus a batch job saturating a healthy service and an
   ordinary change on a victim just before its symptoms. Opus will fix the primary, then lose
   score by stopping early, chasing the decoy or missing the masked fault. Expected Opus 0.7-0.9.
   Sources: ORCA-bench (arXiv 2607.28545), OpenRCA 2.0 (arXiv 2606.27154), SRE book ch. 1 and 12.
2. **Acting costs (level 2 = level 1 worlds).** Telemetry queries take 2 minutes, starting a
   mitigation 1 minute, rollback and restart disrupt more. Opus's habit of 5-11 queries per fault
   now burns 10-20 minutes of outage per fault. Expected Opus 0.6-0.85. Sources: SRE Workbook
   ch. 5, "Generic mitigations" (Mace).

Build: a builder sub-agent built both levels; a server restart cut it off before its report, so
the owner ran the gates and the Harbor check himself. Test gate (levels 0, 1, 2, all eight seeds):
replays identical, stop-early 0.00, exploiter <= 0.47, fuzz-best <= 1.00, reference >= 0.92 of an
oracle that knows the faults, any one fault skipped <= 0.83. Scripted caricatures at level 2:
no-late 0.24-0.79, loudest-first 0.20-0.85, thorough (reads everything first) 0.10-0.75.

Deviations, to save clock: screen and frontier runs started together, and the verifier reviewed
while they ran. An extra Opus run on level 1 separates the two levers.

Measure (held-out seed 101, one run each):

| level | Sonnet 5.5 | Opus 5.5 | Gemini 3.1 Pro | gap (frontier) |
| --- | --- | --- | --- | --- |
| 1 (lever 1) | - | 0.97 | - | 0.03 (Opus only) |
| 2 (levers 1+2) | 0.95 | 0.94 | 0.80 | **0.13** |

- Opus adapted to the clock at once: 3 queries before its first fix at level 2 (8 at level 1,
  where they are free), no wasted mitigation, the decoys ignored, the late fault caught. Its 0.06
  loss is delay: it polls every 4-5 minutes and reads two things before the late fix.
- Gemini lost 0.20: it restarted the service running the batch job (the loud decoy, $2,000 and a
  50% disruption) and made 8 queries before its first fix. Meaningful: this is "locks onto the
  loudest symptom".
- Ablation by level: lever 1 alone costs Opus 0.03, lever 2 adds 0.03.

Verify (GPT 6.1 Sol, fresh): no receipt forgery, no future leak, no replay mismatch. Four findings:

1. A blind cycle of mitigations (config revert, rollback, failover, scale on whatever alerts)
   scored 0.95 on seed 4 at level 2, because three wasted mitigations cost $6,000 of $170,000.
   **Accepted.** Fixed from level 3 on: a wasted mitigation costs $10,000 and a `shotgun` policy
   is in the gates (<= 0.61). Level 2 keeps the weakness, since its runs were already measured.
2. A faster legal policy beats the reference on seed 3 (acts from the alert list alone).
   **Accepted as a limit**: the reference is an anchor, not an optimum; the score is clipped at 1
   and the oracle bound is printed by `eval.py`. It caps the gap, it does not inflate it.
3. The 400-call budget was not in the instruction. **Fixed** (instruction says it).
4. `get_logs` said "last 10 minutes" but showed current rates. **Fixed** (relabelled).

Ratchet: **kept**. Gates passed, the frontier gap grew from 0.00 to 0.13. Opus alone is still
above 0.9, so by the gate rule round 2 is the last chance for the levers.

### Round 2: lever 3 (plan 11:03, build commit ec945c5)

Hypothesis: Opus loses only minutes because everything that costs money also alerts, the alert
list is complete, and the logs name the change. Level 3 removes those three comforts and aims at
outright misses, not delay:

1. **Scale and partial views.** 60 services, one rich edge; `list_alerts` shows the 10 loudest;
   metric and log windows are 30 and 10 minutes. Source: SRE Workbook ch. 5 (alert on budget burn,
   not raw error rate).
2. **A quiet, costly gray failure.** A fourth fault of 3-4.5% on the rich edge's path: nothing
   alerts, the faulty service's own telemetry is clean, only its callers' logs name it, and a
   caller has an innocent change just before. Source: Huang et al., "Gray Failure", HotOS 2017.
3. **The cause sits in a diff.** Logs carry a symptom, not the change id; each change-caused fault
   has a twin change of the other type within 2 minutes, so only `get_diff` separates rollback
   from config revert. Source: SRE book ch. 1 and ch. 12.

Expected Opus 0.6-0.85: it will fix the loud faults and either never chase a 4% error on the rich
edge or blame the caller.

Build (fresh builder): level 3 as specified. Test gate, all levels: replays identical, stop-early
0.00, exploiter 0.00, shotgun <= 0.61, fuzz-best 0.00, trusting <= 0.63, alerts-only <= 0.73.
Two targets missed and relaxed, with reasons: the reference avoids 0.79-0.89 of what the oracle
avoids (target 0.85), because the oracle pays nothing to look and the reference pays 6-13 clock
minutes per fault; and leaving one fault alone is measured against the oracle's saving for the
same reason (quiet fault skipped <= 0.69).

Measure (level 3, held-out seed 101, one run each, commit ec945c5):

| Sonnet 5.5 | Opus 5.5 | Gemini 3.1 Pro | gap (frontier) |
| --- | --- | --- | --- |
| 0.64 | 0.88 | 0.41 | **0.36** |

- **Opus 0.88, first time under 0.9.** All four causes fixed, nothing wasted. It lost on the quiet
  fault: it saw the 4.5% on the rich edge, then searched breadth-first with `get_metrics` on a
  dozen services (2 minutes each) and fixed it at about minute 59; the reference follows the
  callers' logs and starts the fix around minute 20. Meaningful: slow search under a clock.
- **Sonnet 0.64.** Rolled back the innocent caller of the quiet fault ("the errors started after
  that deploy"), $10,000 and a 30% disruption on the rich edge, then found the real cause.
  Meaningful: trusted timing over the diff it had just read.
- **Gemini 0.41.** Three wasted mitigations ($30,000): rolled back the same innocent caller, then
  reverted a config and restarted a service on the cheap edge. Meaningful: mitigates on suspicion.

Verify: the first reviewer run died on a dropped stream (no findings returned); a fresh reviewer
was started at 11:31. Its findings are recorded under round 3.

Ratchet: **kept**. Frontier gap 0.13 -> 0.36, Opus 0.94 -> 0.88, and the level is more realistic
(scale, partial views, diffs), not less. Level 3 is the submit candidate, so round 3 confirms it.

### Round 3: confirm level 3 (started 11:31)

No new lever. Opus on held-out 101 (second run), 102, 103 and Gemini on 102, 103, so that with
round 2 there are 4 Opus and 3 Gemini runs on level 3. Started before the reviewer reported, to
save clock; if a finding changes the simulator, the saved action logs are replayed under the fix.

Measure (level 3, commit ec945c5; last Opus run on 12beed3 after the fixes):

| seed | Opus 5.5 | Gemini 3.1 Pro |
| --- | --- | --- |
| 101 | 0.88 (round 2), 0.93, 0.90 (after fixes) | 0.41 (round 2) |
| 102 | 0.93 | 0.00 |
| 103 | 0.93 | 0.31 as run, 0.40 after the fairness fix |
| mean | **0.91** | **0.27** (0.24 as run) |

Gap 0.41 (frontier), 0.09 for Opus alone. Opus fixes every fault with nothing wasted; it trails
the reference by 2-20 minutes per fix. Gemini wastes 2-4 mitigations per run.

Verify (GPT 6.1 Sol, fresh, level 3): no replay mismatch, no future or seed leak, malformed
arguments rejected, correct mitigations never charged. Two findings, both shortcuts around reading
a diff that matched the reference's cost on every build seed:

1. Harmful diffs were always longer than ordinary ones. **Fixed**: every diff is two hunks in
   either order.
2. Logs at an earlier `until_minute` separated the twin changes by timestamp. **Fixed**: the twin
   lands in the same minute, listed before or after the cause.

After the fixes the reviewer's two shortcut policies score 0.30-0.82 on the build seeds. The fix
exposed a word shared by one symptom and an ordinary diff ("from"), which made the reference roll
back the wrong change on build seed 4; the symptom is reworded. Saved action logs replay to the
same costs under the fixed simulator.

Fairness fix from the transcripts: scaling a service back to its normal replica count was charged
as a wasted mitigation, which punished Gemini twice for undoing its own mistake. Now free.

Verify of the fixes (GPT 6.1 Sol, fresh): no scale exploit (up/down cycles still pay for every
scale-up), no ambiguous symptom (each of the 14 twin pairs on the build seeds has exactly one
related diff), no replay break. One finding: knowing the catalogue of ordinary hunks from the
source, the harmful one can be picked by length arithmetic. **Rejected as an exploit, kept as a
limit** (see the report): the agent cannot see the source, and telling a routine hunk from an
unusual one is the diagnosis the level asks for.

Ratchet: level 3 with the fixes is kept as the final state. **Stop: Opus is above 0.9 after two
lever rounds (0.94, then 0.91 confirmed), so no further lever round is run.**

## Second budget (from 12:11 EET): widen the Opus gap

The team picked incident response. New budget: up to 6 more rounds (4-9), $25 more of agent runs,
stop by 18:00 EET. Same fixed metrics, same held-out seeds 101-103, no new seeds until Opus is
clearly low. The branch was rebased onto main (its commits were already there as cherry-picks).

Decisions:

- Opus's whole loss so far is delay, so the new levers aim at judgment: situations where the
  obvious mitigation is wrong and the evidence against it is reachable but has to be looked for.
- Every new rule comes from a public postmortem (`postmortems.md`) and is disclosed in the
  instruction in general terms; the numbers an expert would need are in the tools.
- One mechanic per round, each a new level on the level-3 world, so ablation stays a level number.
- The reference is strengthened inside each round where the new mechanic needs it; a separate
  speed-up of its search is left for a round where no lever is in flight (two builders in
  `policies.py` at once would collide).

### Round 4: research, then retry storms and mitigations that backfire (plan 12:25)

Research: `postmortems.md` (Cloudflare Nov 2025 and Feb 2026, GitHub Oct 2026, AWS Oct 2025,
Microsoft 365 Nov 2026, whose full report is not out yet).

Hypotheses (level 4 = level-3 world + retries):

1. **Recovery dynamics.** Callers retry failed calls. A service that runs hot is pushed into
   overload by its own retries when a fault fails part of its requests, and stays there after the
   fault is fixed, until load is shed (`throttle`) or capacity added. Opus will fix the cause, see
   the errors stay, and either doubt its diagnosis (wasted mitigations at $10,000) or take long to
   read it as a retry storm. Sources: AWS Oct 2025 (DWFM congestive collapse, throttled to
   recover), Cloudflare Nov 2025 (login backlog plus retries), Bronson et al. HotOS 2021.
2. **Mitigations that backfire.** A rollback or restart fails 30-50% of requests while it runs;
   on a hot, retried service that alone starts a storm. The quiet fault on the rich edge is a bad
   deploy on such a service, so the correct rollback takes the rich edge from 4.5% errors to a
   collapse unless the agent throttles or scales first. Sources: Microsoft 365 Nov 2026 (restarted
   servers fell over when traffic returned), GitHub 5 and 21 Oct 2026.
3. **A throttle is a tool with a bill.** It sheds revenue while it is on and nothing lifts it for
   you (AWS relaxed its throttles seven hours after applying them).

Expected Opus 0.6-0.8: at least one unprotected rollback per shift, or a storm left to burn.

Landing on main: from 12:49 each committed round is merged with `origin/main` and pushed to
`main` as a fast-forward as well as to the branch (the research and this plan landed as 503f08c).

Build (fresh builder, two passes, commit 3d2ef54): level 4 = level 3's services and faults with
state from minute to minute, `callers_retry` in the topology, `retry_share` in metrics, a storm
log line, `throttle`, and a storm-aware reference and oracle. The first pass fined a pre-emptive
scale $10,000 and protected the quiet fault's rollback with a 35% throttle that cost about as
much as the fault; the builder flagged the fine as unfair. Decision: **at level 4 `scale` is never
fined**, its cost is its replica-minutes (GitHub, 5 Oct 2026: "failed over ... one service at a
time, and added capacity"). Scaling everything scores at most 0.02, so no fine is needed to stop
it. Two level-4 parameters differ from level 3: the rich edge earns more (`gray_share` 0.6, so the
quiet fault is still worth fixing after paying for the protected rollback) and a hot service runs
at cpu 0.76, not 0.8 (so the quiet fault's own retries stay under the cpu alert).

Test gate (levels 0-4, eight seeds): replays identical, levels 0-3 unchanged, stop-early and
exploiter 0.00, fuzz-best 0.00, reference 0.76-0.84 of the oracle. Scripted caricatures at level
4: no-drain (fixes causes, never drains a storm) 0.00 on every seed, unprotected (rolls back the
quiet fault without protecting) 0.54-0.74, forgetful (never lifts a throttle) 0.24-0.51,
alerts-only 0.67-0.79, shotgun <= 0.64.

Landing rule, as corrected by the supervisor at 13:20: no merge commits. After each committed
round: `git fetch origin && git rebase origin/main`, rerun the quick gate if the rebase touched
this folder, `git push origin HEAD:main` (fast-forward only), then
`git push --force-with-lease origin loop/aq-incident`. The one merge (503f08c) stays on main.

Measure (level 4, held-out seeds, commit 3d2ef54). Screen and frontier on 101 first; the screen
held (Sonnet 0.26), so Opus was confirmed on all three seeds.

| seed | Opus 5.5 | Gemini 3.1 Pro | Sonnet 5.5 |
| --- | --- | --- | --- |
| 101 | 0.57, 0.37 | 0.00 | 0.26 |
| 102 | 0.65 | 0.00 | - |
| 103 | 0.70 | - | - |
| mean | **0.57** (4 runs) | **0.00** (2 runs) | 0.26 |

Gap 0.71 (frontier), **0.43 for Opus alone** (0.09 at level 3).

Opus's failures, classified from the transcripts before counting them as a gap. All four are
judgment, not delay, and each was avoidable with what the tools showed:

| Run | Score | What went wrong | In its own words | Class |
| --- | --- | --- | --- | --- |
| `r4-l4-s101-opus-130256` | 0.57 | Read a real traffic overload as a retry storm: held an 85% throttle on it for 28 minutes instead of scaling. First mitigation at minute 38 (reference: 8). It did protect the quiet fault's rollback. | "When I lifted the throttle, pricing-svc fell straight back into overload. Its real traffic is now larger than 6 replicas can handle" | meaningful: `rps` x (1 - `retry_share`) against the earlier rps separates the two |
| `r4-l4-s101-opus-131137` | 0.37 | Rolled back the quiet fault's hot service without protecting it; the rich edge went from 4.7% to a collapse. Also held a 50% throttle for 13 minutes. | "The rollback failed some requests, and the retries overloaded quotes-svc. partner-api errors rose to about 56-70% for roughly 6-8 minutes, which was costly." | meaningful: the instruction states the rule, and the same model protected this rollback in the other run |
| `r4-l4-s102-opus-131058` | 0.65 | Picked between the twin changes without reading them; throttled an overloaded service before scaling it; two fixes 23-33 minutes behind the reference. | "I reverted the config change first without reading what it did, and that didn't help, so it will probably be charged as a $10k wasted mitigation." | meaningful |
| `r4-l4-s103-opus-131117` | 0.70 | Took the quiet fault for the baseline and never fixed it: 4% on a $21,600/min edge, $864 a minute for the whole shift. It never queried an edge's history, which shows 0.1-0.3% before the fault. | "all four customer-facing services ended back at their normal 4% error rate. Admin-portal ($21.6k/min) and partner-api were never affected." | meaningful: one `get_metrics` with `until_minute` refutes "normal" |

A pattern across the four: a throttle left on for 12-28 minutes while Opus spends 2-minute queries
on something else (the reference holds its throttles for one minute). Nothing in these runs was
charged unfairly, and no tool output contradicted the instruction.

Gemini (0.00 twice): first action at minute 30-42, wasted mitigations, and an unprotected rollback
of the quiet fault that collapsed the rich edge for 16-27 minutes. Sonnet (0.26): left a storm
burning for 41 minutes after its fix and rolled back the innocent caller.

Verify (GPT 6.1 Sol, fresh): 3,343 accepted random actions replayed exactly; 256,118 comparisons
of past state unchanged by later actions; no state shared between two estates; no negative cost,
type bypass or concurrency shortcut; blanket scale and throttle policies score zero; the reference
is never fined; hot services do not give the faults away (13-24 hot services per build seed, 2-3
of them faulty). Three findings:

1. `retry_share` was exactly zero on every healthy service, so the quiet fault's 0.11 was a
   binary tell. **Fixed**: a calm service shows up to 0.02 of background retries. The quiet
   service's share still stands out to someone who looks, which is the differential observability
   the gray-failure paper describes, not a leak. Reference costs moved by under 0.5%.
2. The quiet fault is always a bad deploy at level 4, so a policy that skips its diffs and rolls
   back (still tracing and protecting) costs about 1% less than the reference. **Kept as a known
   limit, fixed in round 5**: the shortcut needs knowledge of the generator from earlier episodes,
   which one shift does not give, and changing the fault type now would change the held-out
   scenarios the Opus runs were measured on. Round 5's level varies the type again.
3. Retries are fed back as a failure share, not a volume, so a throttle does not reduce the next
   minute's retry multiplier in proportion. **Accepted as a simplification** of the model; it
   makes throttles slightly less effective than in a volume model, the same for agent and
   reference.

Ratchet: **kept**. Gates passed; frontier gap 0.41 -> 0.71, Opus 0.91 -> 0.57, with every rule
traced to a public incident. Level 4 is the new submit candidate.

Landed: round 4 is on `main` as 32a154d (rebased, no merge; main had moved once, so the rebase
ran twice).

### Round 5: a fault on a cycle and a decoy of the wrong class (plan 13:25)

Opus is now clearly low on level 4, so the remaining levers are added for breadth and realism,
and measured against level 4 as the bar: the round is kept only if Opus does not recover.

Hypotheses (level 5 = level 4 with a different primary fault and one more decoy):

1. **A fault that fails and recovers on a cycle.** One service publishes a generated file every
   5 minutes that others load; after a config change at the publisher the file is bad on some
   cycles and, later in the shift, on all of them. Consumers fail while they hold a bad file and
   recover with the next good one, except a hot consumer, whose retry storm outlives the cycle.
   Opus will look during a good cycle (clean logs), drain the storm, see recovery, and be wrong
   five minutes later; or it will mitigate a consumer. Source: Cloudflare, 18 Nov 2025 ("the
   entire system would recover and then fail again"); GitHub, 7 Oct 2026 (the same outage twice).
2. **A coincidental decoy of the wrong class.** A traffic bump within headroom raises CPU alerts
   on healthy hot services, and an external status page goes down at the same time. Together with
   errors that come in waves this reads as a surge or an attack; the wrong-class response is to
   throttle or scale. Source: Cloudflare, 18 Nov 2025 (status page, suspected DDoS); Microsoft
   365, Nov 2026 ("the elevated load isn't driven by an increase in traffic").
3. **The quiet fault's type varies again** (bad deploy or bad config), which removes the
   predictability the round-4 review found.

Expected Opus <= 0.6.

Build (fresh builder, two passes, about 60 minutes, not committed): level 5 ran end to end in
Harbor (reference 1.0, do-nothing 0.0) with the bad-file fault, the campaign and status-page
decoys and a varying quiet-fault type, and levels 0-4 unchanged. **Test gate failed**: the
reference reached only 0.54-0.82 of the oracle (bar 0.75; under it on 8 of 15 seeds, including
two held-out seeds the builder may not inspect), `no-late` equalled the reference on five seeds,
and the quiet fault could be skipped for more than 0.75 on two. Causes the builder found: the
traffic campaign breaks the reference's sizing of an overloaded service (the calm window ends
before the campaign starts), and the reference reaches the quiet fault only after the file fix
and a round of throttles. It also left open whether the top-10 alert cut can hide a failing
consumer from a careful human.

Ratchet: **reverted** (the working tree was restored to level 4; the work is kept as
`jobs/patches/round5-level5-wip.patch`, outside git). Reason: no agent run is spent against a
reference that is not a fair bar, and an unsettled fairness question is a bug, not difficulty.
Cost of the round: $0 of agent runs. What carries over: the bad-file fault alone looked sound;
the campaign decoy is what interacted badly, so the retry (round 7) drops it.

### Round 6: more held-out seeds for level 4 (started 14:02)

No new lever. Opus is clearly low on level 4, so the seed set is widened as the supervisor
allowed: three new held-out seeds 104-106, one Opus run each, and Gemini's third seed (103).
Level 4 passes every gate on 104-106 without any change (reference 0.76-0.84 of the oracle,
no-drain 0.00, unprotected 0.56-0.71). The owner saw the fault lists of 104-106 in the gate
output; nothing was tuned afterwards.

### Round 7: the cycle fault again, without the campaign (plan 14:05)

Hypothesis as round 5's first one. Changes from round 5: the traffic campaign is dropped (the
status page stays as the coincidental decoy), and the builder starts from the saved patch with
one job: a reference that holds at 0.75 of the oracle on build seeds 1-12.

Round 6 measure (level 4, commit 32a154d, one run each):

| seed | Opus 5.5 | note |
| --- | --- | --- |
| 104 | 0.79 | protected the quiet fault's rollback; left a retry storm 25 minutes before scaling it away |
| 105 | 0.00 | cost above doing nothing |
| 106 | 0.00 | cost above doing nothing |

Gemini on 103: 0.00 (its third seed; 0.00 on all three).

Opus on level 4 is now 7 runs on 6 held-out seeds: 0.57, 0.37, 0.65, 0.70, 0.79, 0.00, 0.00,
**mean 0.44** (0.57 on the fixed seeds 101-103). The two zeros are the same failures as before,
only costlier, and are classified meaningful:

- `r6-l4-s105-opus-140306`: a 90% throttle for 19 minutes on a service that was overloaded by
  real traffic (it needed replicas), an unprotected rollback of the quiet fault's hot service,
  and the wrong one of two twin changes reverted first ("I reverted the wrong currency-svc change
  first, which costs a $10,000 wasted-mitigation charge").
- `r6-l4-s106-opus-140329`: an unprotected rollback of the quiet fault's service on the rich
  edge ($11,200/min), whose storm ran 12 minutes before a throttle, and a rollback of the
  innocent caller ("I rolled back payouts-svc when it didn't need it. That cost a $10k
  wasted-mitigation charge, plus about 6 minutes of roughly 30% errors on partner-api, our
  biggest earner"). On this seed the faults are small, so that one storm costs about as much as
  everything a perfect shift could save.

A score of 0 means the shift cost more than doing nothing: the mitigations did more damage than
the faults, which is what the Microsoft and GitHub incidents in `postmortems.md` describe. It is
not a simulator artefact: the reference on the same seeds scores 1.0 with the same tools, and
Opus protected the same kind of rollback correctly in three of its seven runs.

Ratchet: nothing to keep or revert (no code change). Level 4's gap holds on new seeds.

Round 7 build (fresh builder, from the saved patch, commit dc27602): the campaign is gone; the
reference reads alerts by tier, looks at a consumer's log at its alert's `firing_since_minute`,
throttles hot consumers together as the good file lands, and no longer blocks the edge trace on
a landed operation. Two level-5 parameters tuned on build seeds: the rich edge earns more
(`gray_share` 0.75) so the quiet fault stays worth fixing, and callers of the consumer the file
takes down retry 5 times so a storm there cannot be ignored. Fairness check by the builder on
seeds 1-12: every failing consumer is in its tier's alert list or reachable down the upstream
log lines. Test gate (levels 0-5, eight seeds, plus level 5 on build seeds 6-12): all pass;
reference 0.76-0.85 of the oracle; consumer-fixer <= 0.35, surge-responder <= 0.47, drain-only
<= 0.53, no-drain <= 0.77, the four blanket exploits <= 0.09.

Round 7 measure (level 5, held-out seeds, commit dc27602). Screen and frontier on 101, then Opus
on 102 and 103:

| seed | quiet fault is | Opus 5.5 | Gemini 3.1 Pro | Sonnet 5.5 |
| --- | --- | --- | --- | --- |
| 101 | a deploy (rollback must be protected) | 0.00 | 0.00 | 0.00 |
| 102 | a config (no protection needed) | 0.88 | 0.20 | - |
| 103 | a config | 0.55 | - | - |
| mean | | **0.48** | **0.10** | 0.00 |

Gap 0.71 (frontier), 0.52 for Opus alone. Level 4 on the same seeds: gap 0.71, Opus-only 0.43.

Opus's failures at level 5, classified from the transcripts:

| Run | Score | What went wrong | In its own words | Class |
| --- | --- | --- | --- | --- |
| `r7-l5-s101-opus-143149` | 0.00 | Rolled back the quiet fault's hot service unprotected on a $22,700/min edge; held a 60% throttle on a service overloaded by real traffic for 76 minutes instead of scaling it. The shift cost more than doing nothing. | "Rollback without headroom: I started the quotes-svc rollback without checking whether it had room to absorb the extra retries. Scaling it first would have avoided the overload, which cost about 20 minutes of partner-api losing around 40% of its revenue." | meaningful (it names the mistake itself) |
| `r7-l5-s103-opus-143847` | 0.55 | Never fixed the quiet fault; fixed the publisher at minute 34 (reference: 8). | "All four customer-facing services ended at a 3.7% error rate, which looks like their normal background level. admin-portal (by far the biggest earner at $18,300/min) sat at 3.7% for the whole shift and was never hit by any of the faults." | meaningful, with a note below |
| `r7-l5-s102-opus-143827` | 0.88 | Delay only: fixes 16-21 minutes behind the reference. | - | meaningful |

Note on "normal background level": on seed 103 the quiet fault reaches all four edges, so after
the loud faults are fixed every edge shows the same 3.7%, and Opus read that as the baseline in
both its level-4 and level-5 runs on this seed. It is refutable with one query (an edge's
`get_metrics` with `until_minute` shows 0.1-0.3% before the fault began), and 3.7% of $18,300 a
minute is the largest loss on the board, so it is classified meaningful. A stricter reading
would have the instruction say what a healthy edge looks like; not done, because an on-call
engineer gets that from the same graph.

What the cycle fault itself added: Opus found the publisher on every seed (through the consumer's
logs and `file_from`), 16-33 minutes after the reference, and never mitigated a consumer. Its
zero on 101 comes from the level-4 mechanics on a richer edge. So lever 2 costs Opus delay, not
judgment; the status page fooled nobody ("it's hosted outside our estate"). Gemini rolled back
the publisher (wrong twin) and restarted a bystander.

Verify (GPT 6.1 Sol, fresh, level 5): 7,200 random calls over 120 episodes replay exactly; no
crash on any argument type; every mitigation on `status-page` is rejected without clock or cost;
a correct publisher revert is never fined and takes effect at the expected generation at all five
offsets; a consumer in a good phase stays traceable through topology and historical logs; no
blind policy reaches 0.9 on the build seeds; no schedule of future cycles, seed or level in any
output. Two findings, both tells that named the faulty publisher without diagnosis:

1. Only the faulty file's consumer had `callers_retry` 5, so its `file_from` named the culprit
   (the shortcut scored 1.0 on build seeds 2-5). **Fixed**: every publisher has one consumer
   with 5.
2. Only the faulty publisher had a same-minute deploy/config pair. **Fixed**: every publisher
   has one, ordinary at the innocent ones, listed in either order.

After the fixes a blind pick among the publishers, followed by the reference, averages 0.77-0.93
on the build seeds (a wrong pick costs $10,000 and time; a lucky one beats the reference by
skipping the diagnosis, which the clip at 1 hides). Null and reference costs did not move on any
of the 15 seeds, and the six saved agent runs replay to the same costs and scores, so the
measurement above stands.

Ratchet: **kept**. Gates and review passed. By the fixed metric the gap is unchanged (0.71 at
level 4 and at level 5 on seeds 101-103) and Opus alone moves from 0.57 to 0.48, inside the noise
of three runs; the round is kept on realism: a fault that comes and goes, a coincidence that is
not a cause, and a quiet fault whose type is no longer predictable, which closes the limit the
round-4 review left open. Level 5 is the hardest level; level 4 remains the better-measured one
(7 Opus runs on 6 seeds).

Landed: rounds 5-7 are on `main` as 675c0bb (rebased, no merge). The rebase brought in other
threads' commits to this folder (a replay app, a README rewrite, `reward.txt` written by the
verifier script, a note in `task.toml`), so the quick gate was rerun on the rebased tree: Harbor
at level 5 gives reference 1.0, do-nothing 0.0, stop-early 0.0 with unchanged costs, and
`eval.py --level 5` passes.

### Round 8: failover onto a standby without headroom (plan 15:00)

First, more evidence for level 5 while the builder works: Opus on held-out 104-106 and Gemini's
third seed (103). Level 5 passes every gate on 104-106 unchanged.

Hypothesis (level 6 = level 5 with a different late fault): the fault that lands mid-shift is a
data service whose primary is gone, on a hot service with retrying callers and a standby smaller
than the primary (`standby_replicas` in the topology). The obvious `failover` moves all traffic
onto too few replicas, which sheds load, which is retried: the failover "works" and the service
stays down. The expert reads the standby's size first and holds traffic back or adds capacity as
part of the failover. Opus so far checks capacity before acting about half the time, so it will
fail over into a storm on some seeds. Sources: GitHub, 5 Oct 2026 ("did not have enough capacity
for the extra demand and began failing too"); AWS, Oct 2025 (automatic failover removed healthy
capacity); Microsoft 365, Nov 2026 (traffic shifted onto the remaining servers).

This is the last lever; if its reference does not hold in one time box it is reverted and the
remaining time goes to the report.

Round 8 measure (level 5 on more seeds, commit 675c0bb, one run each):

| seed | Opus 5.5 | note |
| --- | --- | --- |
| 104 | 0.57 | protected its rollback; left a retry storm 30+ minutes before draining it |
| 105 | 0.81 | delay only |
| 106 | 0.36 | unprotected rollback of the quiet fault: "The most expensive mistake was mine: the orders-db rollback pushed it into overload, and partner-api ($14k/min) was failing more than half its requests for several minutes." |

Gemini on 103: 0.25 (level 5 on its three seeds: 0.00, 0.20, 0.25, mean 0.15). Opus on level 5
is now 6 runs on 6 held-out seeds, mean 0.53 (0.48 on the fixed seeds). All classified meaningful.

Round 8 build (fresh builder, 21 minutes, not committed): level 6 ran in Harbor (reference 1.0,
do-nothing 0.0) and passed on build seeds 1-12, with levels 0-5 unchanged. **Test gate failed**
on two held-out seeds by a hair (reference 0.749 of the oracle on 101; one fault skippable for
0.905 on 102), and the builder flagged a loophole in its own rule: scaling a data service to its
normal count is free and sizes the standby, so sizing every small standby at minute 0 beats any
judgment at the failover. It also raised the rich edge's share again (`gray_share` 1.3), the
third level in a row to need that.

Ratchet: **reverted**, as committed to in the plan (kept as `jobs/patches/round8-level6-wip.patch`,
outside git). Reasons: the gate failed; the loophole needs a rule change (charge for standby
replicas) and a fresh review; and each new level has needed a richer rich edge to keep its faults
worth fixing, which concentrates the whole score in one mistake on one path. The lever would have
tested the same judgment (capacity before action) that levels 4 and 5 already test. Cost: $0.

### Round 9: closing evidence (started 15:28)

No new lever. A second Opus run on each fixed seed at level 5, so level 5 has the same basis as
level 4, then the final report.

Round 9 measure (level 5, second run per fixed seed, commit 675c0bb):

| seed | Opus 5.5 | note |
| --- | --- | --- |
| 101 | 0.65 | protected the rollback it collapsed on in round 7; held an 85% throttle on a really overloaded service for 23 minutes |
| 102 | 0.89 | delay only |
| 103 | 0.21 | rolled back the quiet fault's service when its config was the cause ($10,000, and the rollback started a storm); 75% throttle for 27 minutes |

Level 5 on the fixed seeds, 6 Opus runs: 0.00, 0.88, 0.55, 0.65, 0.89, 0.21, mean 0.53; Gemini
0.15 (3 runs). Gap 0.66, Opus alone 0.47. Level 4 on the same seeds: gap 0.71, Opus alone 0.43.

Ratchet, final word on round 7: with the full basis level 5 does **not** widen the gap (0.66
against 0.71 by the fixed metric, inside run-to-run noise; Opus 0.53 against 0.57). It is kept in
the tree because level 4 is byte-identical with or without it and it closes level 4's known
limit, but it is not the submit candidate: **level 4 is.**

Stop: 15:31, round 9 of 9, $13.08 of the second $25.

## Third budget (from 15:33 EET): harden level 4 for submission

Granted by Mikael after the report: one more round, with what is left of the second budget's
dollars ($11.92) and the 18:00 stop. No new lever.

### Round 10: default level, healthy baseline, re-measure (plan 15:33)

1. **Default level pinned to 4.** `run.sh` and `eval.py` played the newest level when none was
   named, which became 5 while the README submits 4. They now default to `incident.SUBMITTED`.
2. **The instruction says what healthy looks like**: "When nothing is wrong, an edge service
   fails well under 1% of its requests. Anything above that is a fault costing money, however
   steady it looks." This settles the one judgment call in the taxonomy (Opus twice read the
   quiet fault's 4% as normal). It is in the level-neutral part, so every level's instruction
   gains the line; the simulator and all costs are unchanged.
3. **Re-measure level 4 the way the judges will**: three Opus runs on each of 101-103 with the
   new instruction, plus one Sonnet and one Gemini run on 101.

Hypothesis: the gap holds, because 14 of Opus's 16 runs on levels 4-5 lost elsewhere. Expected
Opus 0.45-0.65. If Opus recovers above 0.8 the gap was the missing sentence, and the report says
so.

Small edits made by the owner, not a builder sub-agent (four lines of code and one sentence).
Test gate: `eval.py` at the default level passes with unchanged costs; Harbor without `LEVEL`
plays level 4 (reference 1.0, do-nothing 0.0 on seed 101).

Measure (level 4 with the new instruction, commit 9dc9187, held-out seeds 101-103):

| seed | Opus 5.5, three runs | Gemini 3.1 Pro | Sonnet 5.5 |
| --- | --- | --- | --- |
| 101 | 0.11, 0.18, 0.73 | 0.00 | 0.02 |
| 102 | 0.03, 0.04, 0.80 | - | - |
| 103 | 0.17, 0.20, 0.59 | - | - |
| mean | **0.31** (9 runs, median 0.18) | 0.00 | 0.02 |

Gap 0.84 (frontier, Gemini on one seed), **0.69 for Opus alone**. Before the sentence: 0.57 over
four runs on the same seeds.

Runs not counted, and why:

- Three Opus runs on seed 101 (`r10-l4-s101-opus-154436`) hit the team's Anthropic spend limit:
  HTTP 400 "usage limits" before the first action, no cost, no action. They are marked
  `excluded` in `metrics.json` and were rerun after the limit was raised
  (`r10-l4-s101-opus-155047`).
- Three Opus runs on seed 102 (`r10-l4-s102-opus-153659`) never started: Harbor's agent setup
  timed out with ten containers running at once. No reward was written, so they are not in
  `metrics.json`; rerun three at a time (`r10-l4-s102-opus-155339`).
- Every counted run was checked: the shift reached minute 120, the agent was charged, and its
  log has no API error. Earlier rounds' runs all had real cost and complete shifts.

The hypothesis was wrong in direction: the sentence did not help Opus, it moved its failure.
On seed 103 all three runs now go after the quiet fault instead of calling it normal, and all
three roll its hot service back without adding capacity first. Across the nine runs:

| What happened | Runs | Scores |
| --- | --- | --- |
| Rolled back the quiet fault's hot service unprotected | 6 of 9 | 0.03-0.59 |
| Added capacity first, then rolled back, nothing wasted | 2 of 9 | 0.73, 0.80 |
| Protected the rollback but rolled back the innocent caller first ($10,000) and fixed late | 1 of 9 | 0.18 |

In Opus's words (`r10-l4-s102-opus-155339`, 0.03): "The rollback failed some requests, and
admin-portal's retries overloaded import-svc, so admin-portal errors rose to about 43%." And on
the other recurring failure (`r10-l4-s101-opus-155047`, 0.11): "I rejected 90% of its requests
for about 20 minutes to stop the storm, scaled it from 6 to 14 replicas, then lifted the limit."
All nine classified meaningful; the "4% is normal" class is gone.

Verify (GPT 6.1 Sol, fresh): no behavioural defect. The sentence is true on build seeds 1-12 at
levels 0-5: with faults removed every edge stays under 1% for the whole history and shift, and
after the reference has run every edge is back under 1% (largest reading 0.4%); it names
symptoms, not causes, and prescribes no fined mitigation. Without `LEVEL`, `eval.py` and a
freshly built variant play level 4, and nothing else assumes the newest level. Level-4 null and
reference costs equal the parent commit's on seeds 1-5. Two findings, both in the README:
"every mitigation on a service that did not need it costs $10,000" is false at level 4 (scale
and throttle are never fined) and "queries move the clock" leaves out the two free ones.
**Fixed** in the README, together with the numbers the new instruction made stale.

Ratchet: **kept**. Gates and review passed; the level is fairer and the gap grew (0.71 -> 0.84
by the fixed metric, Opus alone 0.43 -> 0.69).

Stop: 16:02. $5.63 this round; $18.70 of the $25 granted at 12:11.
